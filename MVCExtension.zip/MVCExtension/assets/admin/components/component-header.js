const { createApp, ref } = Vue

let hafCore = Vue.createApp({});

hafCore.component('niel', {
  
  template: `<h1> Hello this is nielsoffice {{ message }}  </h1>`,
  data() {
    const message =  ref('full stack development');
    return {
        message
    }
  }

});

hafCore.mount('#hafcore_header');