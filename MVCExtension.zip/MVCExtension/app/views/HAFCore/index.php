<?php app_get_header('header', APPVIEWS_INC_HAFCORE); ?>
 

 <h1>Hello By HAFCore</h1>

<?php app_get_header('header', APPVIEWS_INC_HAFCORE); ?>