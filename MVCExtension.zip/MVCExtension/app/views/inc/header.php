
<nav>
    <ul>
        <li><a href="<?php echo URLROOT ?>">Home</a></li>
        <li><a href="<?php echo URLROOT . '&pages=about' ?>">About</a></li>
        <li><a href="<?php echo URLROOT . '&pages=settings' ?>">Settings</a></li>
  
    </ul>
</nav>
