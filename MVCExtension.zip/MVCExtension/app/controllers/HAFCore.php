<?php 

namespace PHPAutoloader\Classes\controllers;

use \PHPAutoloader\Classes\libraries\Controller;


Class HAFCore extends Controller {

    public function __construct()
    {
        
        add_action('mvc_extension_haf_core',[$this,'mvc_extension_haf_core_response']);
    }

    public function mvc_extension_haf_core_response() {
      
       $this->view('HAFCore/index');

    }
}